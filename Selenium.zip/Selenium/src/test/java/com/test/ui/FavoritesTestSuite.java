package com.test.ui;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        AmazonTest.class,
        YoutubeTest.class
})
public class FavoritesTestSuite {
}
