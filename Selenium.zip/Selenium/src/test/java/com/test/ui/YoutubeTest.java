package com.test.ui;

import com.test.ui.rule.WebDriverResource;
import org.junit.ClassRule;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.concurrent.TimeUnit;

public class YoutubeTest extends BasicTest {

    @ClassRule
    public final static WebDriverResource webDriver = new WebDriverResource();

    @Test
    public void searchForPizzaTest() throws Exception
    {
        webDriver.getWebDriver().get("http://www.youtube.com");
        WebElement searchBar = webDriver.getWebDriver().findElement(By.id("search"));
        searchBar.sendKeys("pizza");
        WebElement searchBtn = webDriver.getWebDriver().findElement(By.id("search-icon-legacy"));
        searchBtn.click();
        webDriver.getWebDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }
}
