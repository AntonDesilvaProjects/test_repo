package com.test.ui;

import org.junit.FixMethodOrder;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

//@RunWith(SpringJUnit4ClassRunner.class)
//@FixMethodOrder(MethodSorters.JVM)
//@TestPropertySource(locations = "file:C:/Apps/application.properties")
public abstract class BasicTest {
}
