package com.test.ui.enviroment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/*
    Loads the properties outside the Spring container. Will be used for accessing properties
    within JUnit Rules which gets executed outside Spring bean lifecycle.
*/
public class TestProperties {
    public static Properties properties = new Properties();
    static {
        try(InputStream inputStream = new FileInputStream("C:/Apps/application.properties")) {
            properties.load( inputStream );
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
