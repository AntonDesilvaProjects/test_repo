package com.test.ui;

import com.test.ui.rule.WebDriverResource;
import org.junit.ClassRule;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class AmazonTest extends BasicTest {

    @ClassRule
    public final static WebDriverResource webDriver = new WebDriverResource();

    @Test
    public void searchForJavaTest() throws Exception
    {
        webDriver.getWebDriver().get("http://www.amazon.com");
        WebDriverWait wait = new WebDriverWait( webDriver.getWebDriver(), 30 );
        WebElement searchBar = wait.until(ExpectedConditions.elementToBeClickable(By.id("twotabsearchtextbox")));
        searchBar.sendKeys("Java");
        WebElement searchBtn = webDriver.getWebDriver().findElement(By.className("nav-input"));
        searchBtn.click();
        webDriver.getWebDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }
}
