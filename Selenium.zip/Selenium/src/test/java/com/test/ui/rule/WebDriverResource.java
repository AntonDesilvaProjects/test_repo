package com.test.ui.rule;

import org.junit.rules.ExternalResource;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class WebDriverResource extends ExternalResource {

    private WebDriver webDriver;

    public WebDriverResource()
    {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        ChromeOptions chromeOptions = new ChromeOptions();
        //chromeOptions.addArguments("--headless");
        //chromeOptions.setBinary("/Apps/chromedriver.exe");
        System.setProperty(ChromeDriverService.CHROME_DRIVER_EXE_PROPERTY, "/Apps/chromedriver.exe");
        webDriver = new ChromeDriver(chromeOptions);
    }

    @Override
    protected void before() throws Throwable {
        super.before();
    }

    @Override
    protected void after() {
        super.after();
        webDriver.close();
    }

    public WebDriver getWebDriver()
    {
        return webDriver;
    }
}
